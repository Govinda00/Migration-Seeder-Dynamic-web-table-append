<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmiDetails extends Model
{
    protected $table = 'emi_details';
    protected $guarded = [];
}
