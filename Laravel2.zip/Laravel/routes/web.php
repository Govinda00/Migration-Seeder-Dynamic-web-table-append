<?php

use App\Http\Controllers\PersonController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/login', 'UserController@index')->name('login');

// Route::post('/login123', 'LoanDetailController@login')->name('login.submit');
// Route::get('/loan-details', 'LoanDetailController@loan')->name('loan-details');
// Route::get('/process-page', 'emiDetailController@index')->name('process-page');
// Route::post('/process-page', 'emiDetailController@EmiDetail')->name('process-data');

Route::get('/people', [PersonController::class, 'index'])->name('people.index');
Route::post('/people', 'PersonController@store')->name('people.store');
Route::post('/people/{id}', 'PersonController@update')->name('people.update'); // Route for updating a person
Route::delete('/people/{id}', 'PersonController@destroy')->name('people.destroy'); // Route for deleting a person
Route::get('/people/{id}/edit', 'PersonController@edit')->name('people.edit'); // Route for editing a person


