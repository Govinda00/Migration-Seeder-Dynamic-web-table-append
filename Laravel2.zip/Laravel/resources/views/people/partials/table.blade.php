@foreach($people as $person)
<tr>
    <td>{{ $person->name }}</td>
    <td>{{ $person->email }}</td>
    <td>{{ $person->phone }}</td>
    <td>{{ $person->gender }}</td>
    <td><img src="{{ asset('storage/' . $person->image) }}" alt="Person Image" style="width: 100px;"></td>
    <td>
        <button class="btn btn-success edit-btn" data-id="{{ $person->id }}">Edit</button>
        <button class="btn btn-danger delete-btn" data-id="{{ $person->id }}">Delete</button>
    </td>
</tr>
@endforeach
