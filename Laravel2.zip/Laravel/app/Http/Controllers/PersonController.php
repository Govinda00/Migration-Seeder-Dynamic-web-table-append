<?php
namespace App\Http\Controllers;

use App\Person;
use Illuminate\Http\Request;

class PersonController extends Controller
{
    public function index(Request $request)
    {
        
        if ($request->ajax()) {
            $query = Person::query();
            if ($request->has('search')) {
                $query->where('name', 'LIKE', "%{$request->search}%")
                      ->orWhere('email', 'LIKE', "%{$request->search}%")
                      ->orWhere('gender', 'LIKE', "%{$request->search}%");
            }
            $people = $query->get();
            return response()->json(view('people.partials.table', compact('people'))->render());
        }
        $people = Person::all();
        return view('people.index', compact('people'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:people',
            'phone' => 'nullable|string|max:15',
            'gender' => 'required|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $path = $request->file('image') ? $request->file('image')->store('images', 'public') : null;
        Person::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'gender' => $request->gender,
            'image' => $path,
        ]);

        return response()->json(['success' => 'Person added successfully']);
    }

    public function update(Request $request, $id)
    {
        $person = Person::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:people,email,'.$person->id,
            'phone' => 'nullable|string|max:15',
            'gender' => 'required|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('images', 'public');
            $person->image = $path;
        }

        $person->update($request->only(['name', 'email', 'phone', 'gender']));

        return response()->json(['success' => 'Person updated successfully']);
    }

    public function destroy($id)
    {
        $person = Person::findOrFail($id);
        $person->delete();

        return response()->json(['success' => 'Person deleted successfully']);
    }

    public function edit($id)
    {
        $person = Person::findOrFail($id);
        return response()->json($person);
    }
}
