<!DOCTYPE html>
<html>
<head>
    <title>Laravel AJAX CRUD</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Laravel AJAX CRUD</h2>
        <p>Name: <?php echo e($person); ?></p>
        </div>
</body><?php /**PATH /var/www/resources/views/people/helo.blade.php ENDPATH**/ ?>